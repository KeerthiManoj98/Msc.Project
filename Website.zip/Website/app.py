from flask import Flask, render_template, request
import numpy as np
from tensorflow.keras.models import load_model
from skimage import io, transform

app = Flask(__name__)

# Load the InceptionV3 model
model_path = "models/mobilenetV2 model.h5"
model = load_model(model_path)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Handle file upload
        uploaded_file = request.files["file"]
        if uploaded_file.filename != "":
            # Save the uploaded file to a temporary directory
            img_path = "static/temp_image.jpg"
            uploaded_file.save(img_path)

            # Preprocess the image
            img = io.imread(img_path)
            img = transform.resize(img, (224, 224, 3))
            img = np.expand_dims(img, axis=0)

            # Make predictions
            predictions = model.predict(img)

            # Determine the class (0 or 1)
            class_label = "Fake" if predictions[0][0] > 0.5 else "Real"

            # Render the result page with prediction
            return render_template("result.html", class_label=class_label)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
